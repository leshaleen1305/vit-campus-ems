# VITyarthi — Campus Event & Resource Manager

A web-based platform to create, manage and discover campus events, book college resources, RSVP and track attendance using QR codes.  
This repository scaffold is generated for the GitHub user **leshaleen1305** and is ready to be populated and pushed to that account.

## Contents
- `backend/` — Node.js + Express API skeleton
- `frontend/` — React + Vite minimal scaffold
- `docs/` — report, diagrams and screenshots placeholder
- `README.md`, `statement.md`, `LICENSE`

## Quickstart (local, development)
### Backend
```bash
cd backend
npm install
cp .env.example .env          # set DB credentials
npm run migrate               # optional, if using migrations
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## GitHub
Create a repository under your account and push this folder:

```bash
git init
git add .
git commit -m "Initial scaffold: VITyarthi project"
git branch -M main
git remote add origin https://github.com/leshaleen1305/VITyarthi.git
git push -u origin main
```

## License
MIT
