# Statement

## Problem Statement
College event planning and resource booking are fragmented across multiple channels (WhatsApp groups, posters, spreadsheets), causing scheduling conflicts, poor visibility, and inefficient resource allocation. VITyarthi centralizes event creation, resource booking, RSVPs, and attendance tracking to improve coordination and analytics.

## Scope (MVP)
- Event creation, discovery and management
- Resource booking (rooms, equipment) with conflict checks
- Role-based user management (student, faculty, admin)
- RSVP and QR-based attendance tracking
- Basic analytics and CSV export

## Target Users
Students, faculty organizers, and college administrators.

## Deliverables
- Source code (frontend + backend)
- README and statement
- Project report (PDF)
- Basic testing stubs
