# Frontend (React + Vite)

This is a minimal scaffold. Recommended:
- Initialize Vite (if you want full scaffold): `npm create vite@latest . -- --template react`
- Configure Tailwind CSS and build pages:
  - Event listing, event create, booking calendar, login/register pages
- Use `axios` to call backend APIs at `http://localhost:4000/api`
