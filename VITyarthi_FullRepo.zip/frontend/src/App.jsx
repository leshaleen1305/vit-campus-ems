import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen p-8">
      <h1 className="text-3xl font-bold">VITyarthi</h1>
      <p className="mt-4">Campus Event & Resource Manager — Frontend scaffold</p>
    </div>
  );
}
