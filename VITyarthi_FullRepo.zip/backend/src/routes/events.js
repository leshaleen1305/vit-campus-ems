const express = require('express');
const router = express.Router();

// Minimal event routes
router.get('/', (req, res) => {
  res.json({events: []});
});

router.post('/', (req, res) => {
  res.status(201).json({message: 'event created (stub)'});
});

router.get('/:id', (req, res) => {
  res.json({id: req.params.id});
});

router.post('/:id/rsvp', (req, res) => {
  res.json({message: 'rsvp created (stub)'});
});

module.exports = router;
