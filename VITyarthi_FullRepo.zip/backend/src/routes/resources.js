const express = require('express');
const router = express.Router();

router.get('/', (req, res) => res.json({resources: []}));
router.post('/', (req, res) => res.status(201).json({message: 'resource created (stub)'}));

module.exports = router;
