const express = require('express');
const router = express.Router();

router.get('/', (req, res) => res.json({message: 'VITyarthi API'}));

const auth = require('./auth');
const events = require('./events');
const resources = require('./resources');

router.use('/auth', auth);
router.use('/events', events);
router.use('/resources', resources);

module.exports = router;
