const express = require('express');
const router = express.Router();

// Placeholder auth routes
router.post('/register', (req, res) => {
  res.status(201).json({message: 'register endpoint (stub)'});
});

router.post('/login', (req, res) => {
  res.json({token: 'fake-jwt-token'});
});

module.exports = router;
