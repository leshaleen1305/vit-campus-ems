# Backend (Node.js + Express)

This is a scaffold for the API. It contains minimal routes and structure.

## Recommended next steps
- Implement Sequelize models in `src/models/`
- Add migrations and seeding
- Implement auth, password hashing and role-based middleware
- Implement booking conflict detection using DB transactions or Postgres exclusion constraints
- Add tests in `tests/` and configure CI
