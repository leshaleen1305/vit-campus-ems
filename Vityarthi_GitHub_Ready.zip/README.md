# VITyarthi — Campus Event & Resource Manager

A complete web-based platform for managing campus events, resource booking, RSVP, QR attendance, and analytics.

## Features
- Event management (create, edit, delete)
- Resource booking with conflict detection
- Role-based authentication (student, faculty, admin)
- RSVP & ticketing with QR codes
- Attendance tracking
- Analytics dashboard

## Tech Stack
- Frontend: React + Tailwind CSS
- Backend: Node.js + Express
- Database: PostgreSQL
- Storage: AWS S3 or local
- Auth: JWT-based sessions

## Setup Instructions
1. Clone repository:
    ```
    git clone https://github.com/lesh aleen1305/VITyarthi.git
    ```
2. Setup backend:
    ```
    cd backend
    npm install
    cp .env.example .env
    npm run migrate
    npm run dev
    ```
3. Setup frontend:
    ```
    cd frontend
    npm install
    npm run dev
    ```

## License
MIT
